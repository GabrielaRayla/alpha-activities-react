import { Form } from "./form";

export const LoginPage = () => {
  return (
    <>
      <h1>Login</h1>
      <Form />
    </>
  );
};
