import { Modal } from "./Modal";
import { Form } from "./form";

export const LoginPage = () => {
  const modallsOpen: boolean = false;

  function formSubmitted() {
    alert("Na próxima aula, clicar aqui vai abrir o modal!");
  }
  return (
    <div>
      {modallsOpen && <Modal children={"Form enviado com sucesso !"} />}
      <h1>Login</h1>
      <Form onSubmit={formSubmitted} />
    </div>
  );
};
