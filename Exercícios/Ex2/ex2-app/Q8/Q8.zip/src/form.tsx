export const Form = () => {
  return (
    <>
      <form action="" className="form">
        <input type="email" placeholder="E-mail" required />
        <input type="password" placeholder="Senha" required />
      </form>
    </>
  );
};
